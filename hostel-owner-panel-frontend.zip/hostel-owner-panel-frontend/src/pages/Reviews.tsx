import { useState } from "react";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Star, MessageCircle } from "lucide-react";

const Reviews = () => {
  const [reviews] = useState([
    {
      id: 1,
      customer: "John Doe",
      hostel: "Sunset Hostel",
      rating: 4,
      comment: "Great experience, very clean and comfortable.",
      date: "2024-02-28",
    },
    // Add more sample data as needed
  ]);

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <main className="flex-1 ml-64 p-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Reviews & Feedback</h1>
        
        <div className="grid gap-6">
          {reviews.map((review) => (
            <Card key={review.id} className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <div className="flex items-center mb-2">
                    <h3 className="text-lg font-semibold mr-2">{review.customer}</h3>
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <p className="text-sm text-gray-500">
                    {review.hostel} • {review.date}
                  </p>
                </div>
                <Button variant="outline" size="sm">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Reply
                </Button>
              </div>
              <p className="text-gray-600">{review.comment}</p>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
};

export default Reviews;