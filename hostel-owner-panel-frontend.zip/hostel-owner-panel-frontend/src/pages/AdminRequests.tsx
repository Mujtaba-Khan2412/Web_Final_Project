import { useState, useEffect } from "react";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import axios from "axios";

// Set base URL for Axios
axios.defaults.baseURL = "http://localhost:5000"; // Update this to your backend URL

const AdminRequests = () => {
  const [complaints, setComplaints] = useState([]);
  const [newComplaint, setNewComplaint] = useState({
    subject: "",
    description: "",
    customerId: "",
  });
  const [users, setUsers] = useState([]); // Store fetched users
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Fetch complaints and users on page load
  useEffect(() => {
    const fetchComplaints = async () => {
      try {
        const response = await axios.get("/api/complaints");
        setComplaints(response.data.complaints);
      } catch (err) {
        console.error("Error fetching complaints:", err);
        setError("Failed to load complaints.");
      }
    };

    const fetchUsers = async () => {
      try {
        const response = await axios.get("/api/users"); // Assuming this endpoint returns all users
        setUsers(response.data);
      } catch (err) {
        if (axios.isAxiosError(err)) {
          console.error("Axios error:", err.response?.data || err.message);
        } else {
          console.error("Unexpected error:", err);
        }
        setError("Failed to load users.");
      }
    };

    fetchComplaints();
    fetchUsers();
  }, []);

  // Handle form submission
  const handleNewComplaintSubmit = async () => {
    if (!newComplaint.subject || !newComplaint.description || !newComplaint.customerId) {
      alert("Please fill out all fields");
      return;
    }

    try {
      setLoading(true);
      setError("");
      const response = await axios.post("/api/complaints", newComplaint);
      setComplaints([...complaints, response.data.complaint]); // Append new complaint to the list
      setNewComplaint({ subject: "", description: "", customerId: "" }); // Reset form
    } catch (err) {
      console.error("Error creating complaint:", err);
      setError("Failed to create complaint. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <main className="flex-1 ml-64 p-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Admin Complaints</h1>

          <Dialog>
            <DialogTrigger asChild>
              <Button className="bg-purple-600 hover:bg-purple-700">
                New Complaint
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Create Complaint</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="subject">Subject</Label>
                  <Textarea
                    id="subject"
                    placeholder="Enter complaint subject"
                    value={newComplaint.subject}
                    onChange={(e) =>
                      setNewComplaint({ ...newComplaint, subject: e.target.value })
                    }
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="customer">Customer</Label>
                  <Select
                    onValueChange={(value) =>
                      setNewComplaint({ ...newComplaint, customerId: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select customer" />
                    </SelectTrigger>
                    <SelectContent>
                      {users.map((user) => (
                        <SelectItem key={user._id} value={user._id}>
                          {user.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Provide details about your complaint..."
                    value={newComplaint.description}
                    onChange={(e) =>
                      setNewComplaint({ ...newComplaint, description: e.target.value })
                    }
                  />
                </div>
              </div>
              <Button
                onClick={handleNewComplaintSubmit}
                className="w-full bg-purple-600 hover:bg-purple-700"
                disabled={loading}
              >
                {loading ? "Submitting..." : "Submit Complaint"}
              </Button>
              {error && <p className="text-red-600 text-sm mt-2">{error}</p>}
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-6">
          {error ? (
            <p className="text-red-600">{error}</p>
          ) : (
            complaints.map((complaint) => (
              <Card key={complaint._id} className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold">{complaint.subject}</h3>
                    <p className="text-sm text-gray-500">
                      Submitted by {complaint.userId.name} on {new Date(complaint.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-sm ${
                      complaint.status === "pending"
                        ? "bg-yellow-50 text-yellow-700"
                        : complaint.status === "resolved"
                        ? "bg-green-50 text-green-700"
                        : "bg-red-50 text-red-700"
                    }`}
                  >
                    {complaint.status}
                  </span>
                </div>
                <p className="text-gray-600">{complaint.description}</p>
              </Card>
            ))
          )}
        </div>
      </main>
    </div>
  );
};

export default AdminRequests;
