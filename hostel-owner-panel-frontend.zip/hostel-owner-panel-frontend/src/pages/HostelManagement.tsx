import { useState } from "react";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Edit, Trash2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import axios from "axios"; // Import axios for HTTP requests

// Set base URL for Axios
axios.defaults.baseURL = "http://localhost:5000"; // Update this to your backend URL

const HostelManagement = () => {
  const [hostels, setHostels] = useState([
    {
      id: 1,
      name: "Sunset Hostel",
      location: "123 Beach Road",
      description: "Beautiful beachfront hostel",
      rooms: 10,
    },
    // Add more sample data as needed
  ]);
  const [newHostel, setNewHostel] = useState({
    name: "",
    location: "",
    description: "",
    rooms: 0,
  });
  const [editHostel, setEditHostel] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Handle input change for form fields
  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setNewHostel((prevState) => ({
      ...prevState,
      [id]: value,
    }));
  };

  // Handle form submission to create new hostel
  const handleAddHostel = async () => {
    if (!newHostel.name || !newHostel.location || !newHostel.rooms) {
      alert("Please fill out all fields");
      return;
    }

    setLoading(true);
    setError("");

    try {
      // POST the new hostel data to the server
      const response = await axios.post("/api/hostels", newHostel);
      setHostels([...hostels, response.data]); // Add the new hostel to the list
      setNewHostel({
        name: "",
        location: "",
        description: "",
        rooms: 0,
      }); // Reset the form
    } catch (err) {
      console.error("Error adding hostel:", err);
      setError("Failed to add hostel. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // Handle deletion of a hostel
  const handleDeleteHostel = async (id) => {
    try {
      await axios.delete(`/api/hostels/${id}`);
      setHostels(hostels.filter((hostel) => hostel.id !== id)); // Remove the hostel from the list
    } catch (err) {
      console.error("Error deleting hostel:", err);
      setError("Failed to delete hostel. Please try again.");
    }
  };

  // Handle editing of a hostel
  const handleEditHostel = (hostel) => {
    setEditHostel(hostel); // Set the hostel to be edited
  };

  // Handle form submission to update a hostel
  const handleUpdateHostel = async () => {
    if (!editHostel.name || !editHostel.location || !editHostel.rooms) {
      alert("Please fill out all fields");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const response = await axios.put(`/api/hostels/${editHostel.id}`, editHostel);
      setHostels(
        hostels.map((hostel) =>
          hostel.id === editHostel.id ? response.data : hostel
        )
      ); // Update the hostel in the list
      setEditHostel(null); // Reset the edit state
    } catch (err) {
      console.error("Error updating hostel:", err);
      setError("Failed to update hostel. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <main className="flex-1 ml-64 p-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Hostel Management</h1>
          <Dialog>
            <DialogTrigger asChild>
              <Button className="bg-purple-600 hover:bg-purple-700">
                <Plus className="w-4 h-4 mr-2" />
                Add New Hostel
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>{editHostel ? "Edit Hostel" : "Add New Hostel"}</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">Hostel Name</Label>
                  <Input
                    id="name"
                    value={editHostel ? editHostel.name : newHostel.name}
                    onChange={(e) =>
                      editHostel
                        ? setEditHostel({ ...editHostel, name: e.target.value })
                        : handleInputChange(e)
                    }
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    value={editHostel ? editHostel.location : newHostel.location}
                    onChange={(e) =>
                      editHostel
                        ? setEditHostel({ ...editHostel, location: e.target.value })
                        : handleInputChange(e)
                    }
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={editHostel ? editHostel.description : newHostel.description}
                    onChange={(e) =>
                      editHostel
                        ? setEditHostel({ ...editHostel, description: e.target.value })
                        : handleInputChange(e)
                    }
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="rooms">Number of Rooms</Label>
                  <Input
                    id="rooms"
                    type="number"
                    value={editHostel ? editHostel.rooms : newHostel.rooms}
                    onChange={(e) =>
                      editHostel
                        ? setEditHostel({ ...editHostel, rooms: parseInt(e.target.value) })
                        : handleInputChange(e)
                    }
                  />
                </div>
              </div>
              <Button
                className="w-full bg-purple-600 hover:bg-purple-700"
                onClick={editHostel ? handleUpdateHostel : handleAddHostel}
                disabled={loading}
              >
                {loading ? (editHostel ? "Updating..." : "Adding...") : (editHostel ? "Update Hostel" : "Add Hostel")}
              </Button>
              {error && <p className="text-red-600 text-sm mt-2">{error}</p>}
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {hostels.map((hostel) => (
            <Card key={hostel.id} className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-xl font-semibold">{hostel.name}</h3>
                  <p className="text-gray-500">{hostel.location}</p>
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="icon" onClick={() => handleEditHostel(hostel)}>
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="icon" className="text-red-500" onClick={() => handleDeleteHostel(hostel.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <p className="text-gray-600 mb-4">{hostel.description}</p>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">
                  {hostel.rooms} Rooms Available
                </span>
                <Button variant="outline">Manage Rooms</Button>
              </div>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
};

export default HostelManagement;
