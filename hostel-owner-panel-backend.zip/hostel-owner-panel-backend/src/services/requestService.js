import Request from '../models/Request.js';
import User from '../models/User.js';

/**
 * Create a new request.
 * @param {Object} requestData
 * @returns {Promise<Object>}
 */
export const createRequest = async (requestData) => {
  try {
    const newRequest = new Request(requestData);
    return await newRequest.save();
  } catch (error) {
    throw new Error(`Error creating request: ${error.message}`);
  }
};

/**
 * Get all requests with optional filters.
 * @param {Object} filters
 * @returns {Promise<Array>}
 */
export const getAllRequests = async (filters = {}) => {
  try {
    return await Request.find(filters)
      .populate('userId', 'name email')
      .populate('managerId', 'name email')
      .sort({ createdAt: -1 });
  } catch (error) {
    throw new Error(`Error fetching requests: ${error.message}`);
  }
};

/**
 * Get a specific request by ID.
 * @param {String} requestId
 * @returns {Promise<Object>}
 */
export const getRequestById = async (requestId) => {
  try {
    const request = await Request.findById(requestId)
      .populate('userId', 'name email')
      .populate('managerId', 'name email');
    if (!request) {
      throw new Error(`Request with ID ${requestId} not found`);
    }
    return request;
  } catch (error) {
    throw new Error(`Error fetching request by ID: ${error.message}`);
  }
};

/**
 * Update a request.
 * @param {String} requestId
 * @param {Object} updatedData
 * @returns {Promise<Object>}
 */
export const updateRequest = async (requestId, updatedData) => {
  try {
    const updatedRequest = await Request.findByIdAndUpdate(requestId, updatedData, { new: true });
    if (!updatedRequest) {
      throw new Error(`Request with ID ${requestId} not found`);
    }
    return updatedRequest;
  } catch (error) {
    throw new Error(`Error updating request: ${error.message}`);
  }
};

/**
 * Delete a request by ID.
 * @param {String} requestId
 * @returns {Promise<Object>}
 */
export const deleteRequest = async (requestId) => {
  try {
    const deletedRequest = await Request.findByIdAndDelete(requestId);
    if (!deletedRequest) {
      throw new Error(`Request with ID ${requestId} not found`);
    }
    return deletedRequest;
  } catch (error) {
    throw new Error(`Error deleting request: ${error.message}`);
  }
};

/**
 * Approve or reject a request.
 * @param {String} requestId
 * @param {String} status
 * @returns {Promise<Object>}
 */
export const handleRequestStatus = async (requestId, status) => {
  try {
    if (!["approved", "rejected"].includes(status)) {
      throw new Error('Invalid status. Use "approved" or "rejected".');
    }
    const updatedRequest = await Request.findByIdAndUpdate(
      requestId,
      { status, updatedAt: new Date() },
      { new: true }
    );
    if (!updatedRequest) {
      throw new Error(`Request with ID ${requestId} not found`);
    }
    return updatedRequest;
  } catch (error) {
    throw new Error(`Error handling request status: ${error.message}`);
  }
};

/**
 * Assign a manager to handle a request.
 * @param {String} requestId
 * @param {String} managerId
 * @returns {Promise<Object>}
 */
export const assignManagerToRequest = async (requestId, managerId) => {
  try {
    const manager = await User.findById(managerId);
    if (!manager || manager.role !== 'hostel_owner') {
      throw new Error(`Manager with ID ${managerId} not found or is not a hostel owner`);
    }
    const updatedRequest = await Request.findByIdAndUpdate(
      requestId,
      { managerId },
      { new: true }
    );
    if (!updatedRequest) {
      throw new Error(`Request with ID ${requestId} not found`);
    }
    return updatedRequest;
  } catch (error) {
    throw new Error(`Error assigning manager to request: ${error.message}`);
  }
};
