import Hostel from '../models/Hostel.js';
import Room from '../models/Room.js';

/**
 * Add a new hostel
 * @param {Object} hostelData
 * @returns {Promise<Object>}
 */
export const addHostel = async (hostelData) => {
  try {
    const newHostel = new Hostel(hostelData);
    return await newHostel.save();
  } catch (error) {
    throw new Error(`Error adding hostel: ${error.message}`);
  }
};

/**
 * Edit an existing hostel
 * @param {String} hostelId
 * @param {Object} updatedData
 * @returns {Promise<Object>}
 */
export const editHostel = async (hostelId, updatedData) => {
  try {
    return await Hostel.findByIdAndUpdate(hostelId, updatedData, { new: true });
  } catch (error) {
    throw new Error(`Error updating hostel: ${error.message}`);
  }
};

/**
 * Delete a hostel
 * @param {String} hostelId
 * @returns {Promise<Object>}
 */
export const deleteHostel = async (hostelId) => {
  try {
    const deletedHostel = await Hostel.findByIdAndDelete(hostelId);
    if (!deletedHostel) {
      throw new Error(`Hostel with ID ${hostelId} not found`);
    }
    // Remove all associated rooms
    await Room.deleteMany({ hostelId });
    return deletedHostel;
  } catch (error) {
    throw new Error(`Error deleting hostel: ${error.message}`);
  }
};

/**
 * Get all hostels
 * @param {Object} filters
 * @returns {Promise<Array>}
 */
export const getAllHostels = async (filters = {}) => {
  try {
    return await Hostel.find(filters)
      .populate('ownerId', 'name email')
      .sort({ createdAt: -1 });
  } catch (error) {
    throw new Error(`Error fetching hostels: ${error.message}`);
  }
};

/**
 * Get hostel by ID
 * @param {String} hostelId
 * @returns {Promise<Object>}
 */
export const getHostelById = async (hostelId) => {
  try {
    const hostel = await Hostel.findById(hostelId).populate('roomIds').populate('ownerId', 'name email');
    if (!hostel) {
      throw new Error(`Hostel with ID ${hostelId} not found`);
    }
    return hostel;
  } catch (error) {
    throw new Error(`Error fetching hostel by ID: ${error.message}`);
  }
};

/**
 * Add a room to a hostel
 * @param {String} hostelId
 * @param {Object} roomData
 * @returns {Promise<Object>}
 */
export const addRoomToHostel = async (hostelId, roomData) => {
  try {
    const room = new Room({ ...roomData, hostelId });
    const savedRoom = await room.save();

    // Add the room to the hostel's roomIds array
    await Hostel.findByIdAndUpdate(hostelId, { $push: { roomIds: savedRoom._id } });

    return savedRoom;
  } catch (error) {
    throw new Error(`Error adding room to hostel: ${error.message}`);
  }
};

/**
 * Remove a room from a hostel
 * @param {String} roomId
 * @returns {Promise<Object>}
 */
export const removeRoomFromHostel = async (roomId) => {
  try {
    const room = await Room.findByIdAndDelete(roomId);
    if (!room) {
      throw new Error(`Room with ID ${roomId} not found`);
    }

    // Remove the room reference from the hostel
    await Hostel.findByIdAndUpdate(room.hostelId, { $pull: { roomIds: roomId } });

    return room;
  } catch (error) {
    throw new Error(`Error removing room from hostel: ${error.message}`);
  }
};

/**
 * Upload hostel images
 * @param {String} hostelId
 * @param {Array<String>} imagePaths
 * @returns {Promise<Object>}
 */
export const uploadHostelImages = async (hostelId, imagePaths) => {
  try {
    return await Hostel.findByIdAndUpdate(
      hostelId,
      { $push: { images: { $each: imagePaths } } },
      { new: true }
    );
  } catch (error) {
    throw new Error(`Error uploading hostel images: ${error.message}`);
  }
};
