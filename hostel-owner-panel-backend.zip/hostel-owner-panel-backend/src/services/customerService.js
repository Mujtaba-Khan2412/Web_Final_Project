import Customer from '../models/Customer.js';
import BookingHistory from '../models/bookingHistory.js';
import Feedback from '../models/Feedback.js';
import Complaint from '../models/Complaint.js';

/**
 * Fetch customer profile by ID
 * @param {String} customerId
 * @returns {Promise<Object>}
 */
export const getCustomerProfile = async (customerId) => {
  try {
    const customer = await Customer.findById(customerId)
      .select('-passwordHash') // Exclude sensitive data
      .populate('hostelDetails.hostelId roomId');
    if (!customer) {
      throw new Error('Customer not found');
    }
    return customer;
  } catch (error) {
    throw new Error(`Error fetching customer profile: ${error.message}`);
  }
};

/**
 * Update customer profile
 * @param {String} customerId
 * @param {Object} updateData
 * @returns {Promise<Object>}
 */
export const updateCustomerProfile = async (customerId, updateData) => {
  try {
    const updatedCustomer = await Customer.findByIdAndUpdate(
      customerId,
      updateData,
      { new: true }
    ).select('-passwordHash');
    if (!updatedCustomer) {
      throw new Error('Customer not found');
    }
    return updatedCustomer;
  } catch (error) {
    throw new Error(`Error updating customer profile: ${error.message}`);
  }
};

/**
 * Fetch customer booking history
 * @param {String} customerId
 * @returns {Promise<Array>}
 */
export const getBookingHistory = async (customerId) => {
  try {
    const bookingHistory = await BookingHistory.find({ userId: customerId })
      .populate('hostelIds', 'name location')
      .sort({ createdAt: -1 }); // Sort by most recent bookings
    return bookingHistory;
  } catch (error) {
    throw new Error(`Error fetching booking history: ${error.message}`);
  }
};

/**
 * Submit feedback for a hostel
 * @param {Object} feedbackData
 * @returns {Promise<Object>}
 */
export const submitFeedback = async (feedbackData) => {
  try {
    const feedback = new Feedback(feedbackData);
    const savedFeedback = await feedback.save();
    return savedFeedback;
  } catch (error) {
    throw new Error(`Error submitting feedback: ${error.message}`);
  }
};

/**
 * File a complaint
 * @param {Object} complaintData
 * @returns {Promise<Object>}
 */
export const fileComplaint = async (complaintData) => {
  try {
    const complaint = new Complaint(complaintData);
    const savedComplaint = await complaint.save();
    return savedComplaint;
  } catch (error) {
    throw new Error(`Error filing complaint: ${error.message}`);
  }
};

/**
 * Fetch all feedback for a customer
 * @param {String} customerId
 * @returns {Promise<Array>}
 */
export const getCustomerFeedback = async (customerId) => {
  try {
    const feedback = await Feedback.find({ userId: customerId })
      .populate('hostelId', 'name')
      .populate('roomId', 'roomNumber');
    return feedback;
  } catch (error) {
    throw new Error(`Error fetching feedback: ${error.message}`);
  }
};
