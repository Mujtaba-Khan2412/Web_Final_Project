import Feedback from '../models/Feedback.js';
import Hostel from '../models/Hostel.js';

/**
 * Submit feedback for a hostel or room
 * @param {Object} feedbackData
 * @returns {Promise<Object>}
 */
export const submitFeedback = async (feedbackData) => {
  try {
    const feedback = new Feedback(feedbackData);
    const savedFeedback = await feedback.save();

    // Optionally update the hostel's average rating if feedback is approved
    if (feedbackData.status === 'approved' && feedbackData.hostelId) {
      await updateHostelRating(feedbackData.hostelId);
    }

    return savedFeedback;
  } catch (error) {
    throw new Error(`Error submitting feedback: ${error.message}`);
  }
};

/**
 * Get all feedback for a hostel
 * @param {String} hostelId
 * @returns {Promise<Array>}
 */
export const getFeedbackForHostel = async (hostelId) => {
  try {
    const feedback = await Feedback.find({ hostelId, status: 'approved' })
      .populate('userId', 'name')
      .sort({ createdAt: -1 });
    return feedback;
  } catch (error) {
    throw new Error(`Error fetching feedback for hostel: ${error.message}`);
  }
};

/**
 * Approve or deny feedback
 * @param {String} feedbackId
 * @param {String} status
 * @returns {Promise<Object>}
 */
export const updateFeedbackStatus = async (feedbackId, status) => {
  try {
    const updatedFeedback = await Feedback.findByIdAndUpdate(
      feedbackId,
      { status },
      { new: true }
    );

    // Update the hostel rating if feedback status is updated to approved
    if (updatedFeedback && status === 'approved' && updatedFeedback.hostelId) {
      await updateHostelRating(updatedFeedback.hostelId);
    }

    return updatedFeedback;
  } catch (error) {
    throw new Error(`Error updating feedback status: ${error.message}`);
  }
};

/**
 * Get all pending feedback for moderation
 * @returns {Promise<Array>}
 */
export const getPendingFeedback = async () => {
  try {
    const feedback = await Feedback.find({ status: 'pending' })
      .populate('userId', 'name')
      .populate('hostelId', 'name');
    return feedback;
  } catch (error) {
    throw new Error(`Error fetching pending feedback: ${error.message}`);
  }
};

/**
 * Calculate and update the average rating of a hostel
 * @param {String} hostelId
 * @returns {Promise<void>}
 */
const updateHostelRating = async (hostelId) => {
  try {
    const feedback = await Feedback.find({ hostelId, status: 'approved' });
    const totalRating = feedback.reduce((sum, item) => sum + item.rating, 0);
    const averageRating = feedback.length ? totalRating / feedback.length : 0;

    await Hostel.findByIdAndUpdate(hostelId, { rating: averageRating });
  } catch (error) {
    throw new Error(`Error updating hostel rating: ${error.message}`);
  }
};
