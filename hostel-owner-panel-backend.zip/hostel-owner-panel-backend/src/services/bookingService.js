import BookingHistory from '../models/bookingHistory.js';
import Hostel from '../models/Hostel.js';
import Room from '../models/Room.js';
import User from '../models/User.js';

// Service to create a new booking
export const createBooking = async (userId, roomId, bookingDate) => {
  try {
    // Check if room is available
    const room = await Room.findById(roomId);
    if (!room || !room.availability) {
      throw new Error('Room is not available for booking');
    }

    // Create new booking history
    const newBooking = new BookingHistory({
      userId,
      hostelIds: [room.hostelId],
      bookingDates: [bookingDate],
    });

    // Save the booking history
    await newBooking.save();

    // Mark room as booked (not available)
    room.availability = false;
    await room.save();

    return newBooking;
  } catch (error) {
    throw new Error(error.message);
  }
};

// Service to get all bookings
export const getAllBookings = async () => {
  try {
    const bookings = await BookingHistory.find().populate('userId hostelIds bookingDates');
    return bookings;
  } catch (error) {
    throw new Error(error.message);
  }
};

// Service to get booking by user ID
export const getBookingsByUser = async (userId) => {
  try {
    const bookings = await BookingHistory.find({ userId }).populate('userId hostelIds bookingDates');
    return bookings;
  } catch (error) {
    throw new Error(error.message);
  }
};

// Service to update booking details
export const updateBooking = async (bookingId, updatedDetails) => {
  try {
    const booking = await BookingHistory.findByIdAndUpdate(bookingId, updatedDetails, {
      new: true,
    }).populate('userId hostelIds bookingDates');

    if (!booking) {
      throw new Error('Booking not found');
    }

    return booking;
  } catch (error) {
    throw new Error(error.message);
  }
};

// Service to cancel booking
export const cancelBooking = async (bookingId) => {
  try {
    const booking = await BookingHistory.findById(bookingId);
    if (!booking) {
      throw new Error('Booking not found');
    }

    // Mark the associated rooms as available again
    const roomIds = booking.hostelIds;  // Assuming that the booking includes hostelIds that correspond to rooms
    for (let roomId of roomIds) {
      const room = await Room.findById(roomId);
      if (room) {
        room.availability = true;
        await room.save();
      }
    }

    // Delete the booking history
    await BookingHistory.findByIdAndDelete(bookingId);

    return { message: 'Booking canceled successfully' };
  } catch (error) {
    throw new Error(error.message);
  }
};
