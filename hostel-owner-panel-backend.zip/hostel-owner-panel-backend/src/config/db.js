import mongoose from 'mongoose';
import dotenv from 'dotenv'; // Import dotenv

// Load environment variables from .env file
dotenv.config();

const connectDB = async () => {
  try {
    const dbURI = process.env.MONGO_ATLAS_URI; // Use the environment variable for security
    if (!dbURI) {
      throw new Error("MongoDB Atlas URI is not defined in environment variables.");
    }

    const options = {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    };

    await mongoose.connect(dbURI, options);
    console.log('Connected to MongoDB Atlas successfully.');
  } catch (error) {
    console.error('Failed to connect to MongoDB Atlas:', error.message);
    process.exit(1); // Exit process with failure
  }
};

export default connectDB;
