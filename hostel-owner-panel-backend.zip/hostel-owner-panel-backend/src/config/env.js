import dotenv from 'dotenv';

// Load environment variables from the .env file
dotenv.config();

const env = {
  MONGO_ATLAS_URI: process.env.MONGO_ATLAS_URI || '',
  PORT: process.env.PORT || 5000,
  JWT_SECRET: process.env.JWT_SECRET || 'your_jwt_secret_key',
  PAYMENT_API_KEY: process.env.PAYMENT_API_KEY || 'your_payment_api_key',
  NODE_ENV: process.env.NODE_ENV || 'development',
};

if (!env.MONGO_ATLAS_URI) {
  console.error("Error: MONGO_ATLAS_URI is not defined in the environment variables.");
  process.exit(1); // Exit the process if required variables are missing
}

export default env;
