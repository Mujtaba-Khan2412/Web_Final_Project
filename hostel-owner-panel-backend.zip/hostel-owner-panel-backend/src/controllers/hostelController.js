import Hostel from '../models/Hostel.js';
import Room from '../models/Room.js';
import User from '../models/User.js';
import Feedback from '../models/Feedback.js';
import Review from '../models/Review.js';


// Create a new hostel
export const createHostel = async (req, res) => {
  try {
    const { name, location, description, rooms, ownerId } = req.body;

    if (!name || !location || !ownerId) {
      return res.status(400).json({ message: 'Please provide all required fields.' });
    }

    // Create a new hostel instance
    const newHostel = new Hostel({
      name,
      location,
      description,
      rooms,
      ownerId,
      isApproved: false, // Default value, you can set logic to approve later
    });

    // Save the hostel to the database
    await newHostel.save();
    res.status(201).json(newHostel);
  } catch (err) {
    console.error("Error creating hostel:", err.message);
    res.status(500).json({ message: "Failed to create hostel. Please try again.", error: err.message });
  }
};


// Get all hostels
export const getAllHostels = async (req, res) => {
  try {
    const hostels = await Hostel.find()
      .populate('ownerId', 'name email') // Populating owner details
      .populate('reviews', 'rating reviewText') // Populating reviews
      .exec();

    res.status(200).json(hostels);
  } catch (error) {
    console.error('Error fetching all hostels:', error.message);
    res.status(500).json({ error: 'Failed to retrieve hostels' });
  }
};

// Get hostel details by ID
export const getHostelById = async (req, res) => {
  const { hostelId } = req.params;

  try {
    const hostel = await Hostel.findById(hostelId)
      .populate('ownerId', 'name email') // Populating owner details
      .populate('roomIds', 'roomNumber pricePerMonth') // Populating room details
      .populate('reviews', 'rating reviewText') // Populating reviews
      .exec();

    if (!hostel) {
      return res.status(404).json({ error: 'Hostel not found' });
    }

    res.status(200).json(hostel);
  } catch (error) {
    console.error('Error fetching hostel details:', error.message);
    res.status(500).json({ error: 'Failed to retrieve hostel details' });
  }
};

// Update hostel details
export const updateHostel = async (req, res) => {
  const { hostelId } = req.params;
  const { name, location, description, categories, amenities, images } = req.body;

  try {
    const hostel = await Hostel.findByIdAndUpdate(
      hostelId,
      { name, location, description, categories, amenities, images },
      { new: true }
    );

    if (!hostel) {
      return res.status(404).json({ error: 'Hostel not found' });
    }

    res.status(200).json({ message: 'Hostel updated successfully', hostel });
  } catch (error) {
    console.error('Error updating hostel:', error.message);
    res.status(500).json({ error: 'Failed to update hostel' });
  }
};

// Delete a hostel
export const deleteHostel = async (req, res) => {
  const { hostelId } = req.params;

  try {
    const hostel = await Hostel.findByIdAndDelete(hostelId);
    if (!hostel) {
      return res.status(404).json({ error: 'Hostel not found' });
    }

    // Optionally, delete rooms associated with the hostel
    await Room.deleteMany({ hostelId });

    res.status(200).json({ message: 'Hostel and associated rooms deleted successfully' });
  } catch (error) {
    console.error('Error deleting hostel:', error.message);
    res.status(500).json({ error: 'Failed to delete hostel' });
  }
};

// Approve or reject a hostel (admin functionality)
export const moderateHostel = async (req, res) => {
  const { hostelId } = req.params;
  const { isApproved } = req.body;

  try {
    const hostel = await Hostel.findById(hostelId);

    if (!hostel) {
      return res.status(404).json({ error: 'Hostel not found' });
    }

    hostel.isApproved = isApproved;
    await hostel.save();

    res.status(200).json({ message: `Hostel ${isApproved ? 'approved' : 'rejected'}`, hostel });
  } catch (error) {
    console.error('Error moderating hostel:', error.message);
    res.status(500).json({ error: 'Failed to moderate hostel' });
  }
};

// Get reviews for a specific hostel
export const getHostelReviews = async (req, res) => {
  const { hostelId } = req.params;

  try {
    const feedback = await Feedback.find({ hostelId })
      .populate('userId', 'name email') // Populating user details
      .exec();

    if (!feedback) {
      return res.status(404).json({ error: 'No reviews found for this hostel' });
    }

    res.status(200).json(feedback);
  } catch (error) {
    console.error('Error fetching hostel reviews:', error.message);
    res.status(500).json({ error: 'Failed to retrieve hostel reviews' });
  }
};
