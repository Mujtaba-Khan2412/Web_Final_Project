import User from "../models/User.js";
import Room from "../models/Room.js";

// Create a new booking
export const createBooking = async (req, res) => {
  const { userId, roomId, checkInDate, checkOutDate, totalAmount } = req.body;

  try {
    // Validate room availability
    const room = await Room.findById(roomId);
    if (!room || !room.availability) {
      return res.status(400).json({ error: "Room is unavailable or does not exist." });
    }

    // Find user and add booking
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: "User not found." });
    }

    const booking = {
      roomId,
      checkInDate,
      checkOutDate,
      totalAmount,
    };

    user.bookings.push(booking);
    await user.save();

    // Update room availability
    room.availability = false;
    await room.save();

    res.status(201).json({ message: "Booking created successfully", booking });
  } catch (error) {
    console.error("Error creating booking:", error.message);
    res.status(500).json({ error: "Failed to create booking" });
  }
};

// Retrieve all bookings
export const getAllBookings = async (req, res) => {
  try {
    const users = await User.find()
      .populate("bookings.roomId", "roomNumber pricePerMonth")
      .exec();

    const bookings = users.flatMap((user) => user.bookings.map((booking) => ({
      userId: user._id,
      userName: user.name,
      userEmail: user.email,
      ...booking._doc,
    })));

    res.status(200).json(bookings);
  } catch (error) {
    console.error("Error retrieving bookings:", error.message);
    res.status(500).json({ error: "Failed to retrieve bookings" });
  }
};

// Retrieve bookings for a specific user
export const getBookingsByUser = async (req, res) => {
  const { userId } = req.params;

  try {
    const user = await User.findById(userId)
      .populate("bookings.roomId", "roomNumber pricePerMonth")
      .exec();

    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    res.status(200).json(user.bookings);
  } catch (error) {
    console.error("Error retrieving user bookings:", error.message);
    res.status(500).json({ error: "Failed to retrieve user bookings" });
  }
};

// Cancel a booking
export const cancelBooking = async (req, res) => {
  const { userId, bookingId } = req.params;

  try {
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    const bookingIndex = user.bookings.findIndex((b) => b._id.toString() === bookingId);
    if (bookingIndex === -1) {
      return res.status(404).json({ error: "Booking not found" });
    }

    const [cancelledBooking] = user.bookings.splice(bookingIndex, 1);
    await user.save();

    // Update room availability
    const room = await Room.findById(cancelledBooking.roomId);
    if (room) {
      room.availability = true;
      await room.save();
    }

    res.status(200).json({ message: "Booking cancelled successfully" });
  } catch (error) {
    console.error("Error cancelling booking:", error.message);
    res.status(500).json({ error: "Failed to cancel booking" });
  }
};

// Retrieve a booking by ID
export const getBookingById = async (req, res) => {
  const { bookingId } = req.params;

  try {
    const user = await User.findOne({ "bookings._id": bookingId })
      .populate("bookings.roomId", "roomNumber pricePerMonth")
      .exec();

    if (!user) {
      return res.status(404).json({ error: "Booking not found" });
    }

    const booking = user.bookings.find(b => b._id.toString() === bookingId);
    res.status(200).json(booking);
  } catch (error) {
    console.error("Error retrieving booking by ID:", error.message);
    res.status(500).json({ error: "Failed to retrieve booking" });
  }
};

// Update an existing booking
export const updateBooking = async (req, res) => {
  const { userId, bookingId } = req.params;
  const { roomId, checkInDate, checkOutDate, totalAmount } = req.body;

  try {
    // Find the user
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    // Find the booking
    const bookingIndex = user.bookings.findIndex((b) => b._id.toString() === bookingId);
    if (bookingIndex === -1) {
      return res.status(404).json({ error: "Booking not found" });
    }

    const updatedBooking = user.bookings[bookingIndex];

    // Update booking details
    if (roomId) updatedBooking.roomId = roomId;
    if (checkInDate) updatedBooking.checkInDate = checkInDate;
    if (checkOutDate) updatedBooking.checkOutDate = checkOutDate;
    if (totalAmount) updatedBooking.totalAmount = totalAmount;

    // Save updated user data
    await user.save();

    // Optionally, you may want to update the room availability if roomId is updated
    if (roomId) {
      const oldRoom = await Room.findById(updatedBooking.roomId);
      if (oldRoom) oldRoom.availability = true;
      await oldRoom?.save();

      const newRoom = await Room.findById(roomId);
      if (newRoom) newRoom.availability = false;
      await newRoom?.save();
    }

    res.status(200).json({ message: "Booking updated successfully", booking: updatedBooking });
  } catch (error) {
    console.error("Error updating booking:", error.message);
    res.status(500).json({ error: "Failed to update booking" });
  }
};

