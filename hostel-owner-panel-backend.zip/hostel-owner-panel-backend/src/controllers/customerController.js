import Customer from '../models/User.js'; // User model which includes bookings
import Feedback from '../models/Feedback.js';
import Complaint from '../models/Complaint.js';

// Get all customer profiles
export const getAllCustomers = async (req, res) => {
  try {
    const customers = await Customer.find({ role: 'customer' })
      .select('-passwordHash') // Exclude sensitive data
      .exec();

    res.status(200).json(customers);
  } catch (error) {
    console.error('Error retrieving customers:', error.message);
    res.status(500).json({ error: 'Failed to retrieve customers' });
  }
};

// Get a specific customer profile
export const getCustomerProfile = async (req, res) => {
  const { customerId } = req.params;

  try {
    const customer = await Customer.findById(customerId)
      .select('-passwordHash') // Exclude sensitive data
      .exec();

    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    res.status(200).json(customer);
  } catch (error) {
    console.error('Error retrieving customer profile:', error.message);
    res.status(500).json({ error: 'Failed to retrieve customer profile' });
  }
};

// Update a customer profile
export const updateCustomerProfile = async (req, res) => {
  const { customerId } = req.params;
  const updates = req.body;

  try {
    const updatedCustomer = await Customer.findByIdAndUpdate(
      customerId,
      updates,
      { new: true }
    ).select('-passwordHash'); // Exclude sensitive data

    if (!updatedCustomer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    res.status(200).json({ message: 'Customer profile updated successfully', updatedCustomer });
  } catch (error) {
    console.error('Error updating customer profile:', error.message);
    res.status(500).json({ error: 'Failed to update customer profile' });
  }
};

// Get booking history for a customer (from User model bookings)
export const getCustomerBookingHistory = async (req, res) => {
  const { customerId } = req.params;

  try {
    const customer = await Customer.findById(customerId)
      .populate('bookings.roomId', 'roomNumber pricePerMonth')
      .exec();

    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    res.status(200).json(customer.bookings);
  } catch (error) {
    console.error('Error retrieving booking history:', error.message);
    res.status(500).json({ error: 'Failed to retrieve booking history' });
  }
};

// Submit feedback
export const submitFeedback = async (req, res) => {
  const { customerId } = req.params;
  const { hostelId, roomId, rating, reviewText } = req.body;

  try {
    const feedback = new Feedback({
      userId: customerId,
      hostelId,
      roomId,
      rating,
      reviewText,
    });

    await feedback.save();

    res.status(201).json({ message: 'Feedback submitted successfully', feedback });
  } catch (error) {
    console.error('Error submitting feedback:', error.message);
    res.status(500).json({ error: 'Failed to submit feedback' });
  }
};

// File a complaint
export const fileComplaint = async (req, res) => {
  const { customerId } = req.params;
  const { managerId, subject, description } = req.body;

  try {
    const complaint = new Complaint({
      userId: customerId,
      managerId,
      subject,
      description,
    });

    await complaint.save();

    res.status(201).json({ message: 'Complaint filed successfully', complaint });
  } catch (error) {
    console.error('Error filing complaint:', error.message);
    res.status(500).json({ error: 'Failed to file complaint' });
  }
};

// Get feedback history for a customer
export const getCustomerFeedback = async (req, res) => {
  const { customerId } = req.params;

  try {
    const feedbacks = await Feedback.find({ userId: customerId })
      .populate('hostelId', 'name')
      .populate('roomId', 'roomNumber')
      .exec();

    res.status(200).json(feedbacks);
  } catch (error) {
    console.error('Error retrieving feedback history:', error.message);
    res.status(500).json({ error: 'Failed to retrieve feedback history' });
  }
};
// Create a new customer profile
export const createCustomer = async (req, res) => {
  const { name, email, password, phoneNumber, address, role = 'customer' } = req.body;

  try {
    // Check if customer already exists
    const existingCustomer = await Customer.findOne({ email });
    if (existingCustomer) {
      return res.status(400).json({ error: 'Customer with this email already exists.' });
    }

    // Create new customer instance
    const newCustomer = new Customer({
      name,
      email,
      passwordHash: password, // You should hash the password before saving it to the database
      phoneNumber,
      address,
      role,
    });

    // Save the new customer to the database
    await newCustomer.save();

    res.status(201).json({ message: 'Customer profile created successfully', newCustomer });
  } catch (error) {
    console.error('Error creating customer profile:', error.message);
    res.status(500).json({ error: 'Failed to create customer profile' });
  }
};
// Delete a customer profile
export const deleteCustomer = async (req, res) => {
  const { customerId } = req.params;

  try {
    // Find and delete the customer
    const deletedCustomer = await Customer.findByIdAndDelete(customerId);

    if (!deletedCustomer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    res.status(200).json({ message: 'Customer profile deleted successfully' });
  } catch (error) {
    console.error('Error deleting customer profile:', error.message);
    res.status(500).json({ error: 'Failed to delete customer profile' });
  }
};
// Get a specific customer profile by ID
export const getCustomerById = async (req, res) => {
  const { customerId } = req.params;

  try {
    // Find the customer by ID
    const customer = await Customer.findById(customerId)
      .select('-passwordHash') // Exclude sensitive data like password hash
      .exec();

    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    res.status(200).json(customer);
  } catch (error) {
    console.error('Error retrieving customer profile:', error.message);
    res.status(500).json({ error: 'Failed to retrieve customer profile' });
  }
};

// Get complaints history for a customer
export const getCustomerComplaints = async (req, res) => {
  const { customerId } = req.params;

  try {
    const complaints = await Complaint.find({ userId: customerId })
      .populate('managerId', 'name email')
      .exec();

    res.status(200).json(complaints);
  } catch (error) {
    console.error('Error retrieving complaints history:', error.message);
    res.status(500).json({ error: 'Failed to retrieve complaints history' });
  }
};

export const updateCustomerStatus = async (req, res) => {
  const { customerId } = req.params;
  const { status } = req.body;

  try {
    const customer = await Customer.findByIdAndUpdate(
      customerId,
      { status },
      { new: true }
    ).select('-passwordHash');

    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    res.status(200).json({ message: 'Customer status updated successfully', customer });
  } catch (error) {
    console.error('Error updating customer status:', error.message);
    res.status(500).json({ error: 'Failed to update customer status' });
  }
};
