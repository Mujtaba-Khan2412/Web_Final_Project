import Feedback from '../models/Feedback.js';
import Hostel from '../models/Hostel.js';
import Room from '../models/Room.js';

// Get all feedback for a specific hostel
export const getHostelFeedback = async (req, res) => {
  const { hostelId } = req.params;

  try {
    const feedback = await Feedback.find({ hostelId })
      .populate('userId', 'name email') // Populating user details
      .populate('roomId', 'roomNumber roomType') // Populating room details
      .exec();

    res.status(200).json(feedback);
  } catch (error) {
    console.error('Error retrieving feedback for hostel:', error.message);
    res.status(500).json({ error: 'Failed to retrieve hostel feedback' });
  }
};

// Get all feedback for a specific room
export const getRoomFeedback = async (req, res) => {
  const { roomId } = req.params;

  try {
    const feedback = await Feedback.find({ roomId })
      .populate('userId', 'name email') // Populating user details
      .populate('hostelId', 'name location') // Populating hostel details
      .exec();

    res.status(200).json(feedback);
  } catch (error) {
    console.error('Error retrieving feedback for room:', error.message);
    res.status(500).json({ error: 'Failed to retrieve room feedback' });
  }
};

// Submit feedback for a hostel or room
export const submitFeedback = async (req, res) => {
  const { customerId } = req.params;
  const { hostelId, roomId, rating, reviewText } = req.body;

  try {
    // Ensure the hostel and room exist
    const hostel = await Hostel.findById(hostelId);
    const room = await Room.findById(roomId);

    if (!hostel || !room) {
      return res.status(404).json({ error: 'Hostel or Room not found' });
    }

    const feedback = new Feedback({
      userId: customerId,
      hostelId,
      roomId,
      rating,
      reviewText,
    });

    await feedback.save();

    // Update the hostel's rating after feedback submission
    const allFeedbacks = await Feedback.find({ hostelId });
    const averageRating = allFeedbacks.reduce((sum, feedback) => sum + feedback.rating, 0) / allFeedbacks.length;

    hostel.rating = averageRating;
    await hostel.save();

    res.status(201).json({ message: 'Feedback submitted successfully', feedback });
  } catch (error) {
    console.error('Error submitting feedback:', error.message);
    res.status(500).json({ error: 'Failed to submit feedback' });
  }
};

// Delete feedback by feedbackId
export const deleteFeedback = async (req, res) => {
  const { feedbackId } = req.params;

  try {
    // Find the feedback by its ID
    const feedback = await Feedback.findById(feedbackId);

    if (!feedback) {
      return res.status(404).json({ error: 'Feedback not found' });
    }

    // Delete the feedback
    await feedback.remove();

    // Update the hostel's rating after feedback deletion
    const allFeedbacks = await Feedback.find({ hostelId: feedback.hostelId });
    const averageRating = allFeedbacks.reduce((sum, feedback) => sum + feedback.rating, 0) / allFeedbacks.length;

    const hostel = await Hostel.findById(feedback.hostelId);
    hostel.rating = averageRating || 0; // If no feedback left, set rating to 0
    await hostel.save();

    res.status(200).json({ message: 'Feedback deleted successfully' });
  } catch (error) {
    console.error('Error deleting feedback:', error.message);
    res.status(500).json({ error: 'Failed to delete feedback' });
  }
};

// Get feedback by ID
export const getFeedbackById = async (req, res) => {
  const { feedbackId } = req.params;

  try {
    const feedback = await Feedback.findById(feedbackId)
      .populate('userId', 'name email') // Populating user details
      .populate('hostelId', 'name location') // Populating hostel details
      .populate('roomId', 'roomNumber roomType') // Populating room details
      .exec();

    if (!feedback) {
      return res.status(404).json({ error: 'Feedback not found' });
    }

    res.status(200).json(feedback);
  } catch (error) {
    console.error('Error retrieving feedback by ID:', error.message);
    res.status(500).json({ error: 'Failed to retrieve feedback by ID' });
  }
};


// Get all feedback
export const getAllFeedback = async (req, res) => {
  try {
    const feedback = await Feedback.find()
      .populate('userId', 'name email') // Populating user details
      .populate('hostelId', 'name location') // Populating hostel details
      .populate('roomId', 'roomNumber roomType') // Populating room details
      .exec();

    res.status(200).json(feedback);
  } catch (error) {
    console.error('Error retrieving all feedback:', error.message);
    res.status(500).json({ error: 'Failed to retrieve all feedback' });
  }
};

// Approve or deny feedback (admin functionality)
export const moderateFeedback = async (req, res) => {
  const { feedbackId } = req.params;
  const { status } = req.body; // 'approved', 'denied'

  if (!['approved', 'denied'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status' });
  }

  try {
    const feedback = await Feedback.findById(feedbackId);

    if (!feedback) {
      return res.status(404).json({ error: 'Feedback not found' });
    }

    feedback.status = status;
    await feedback.save();

    res.status(200).json({ message: 'Feedback status updated', feedback });
  } catch (error) {
    console.error('Error moderating feedback:', error.message);
    res.status(500).json({ error: 'Failed to moderate feedback' });
  }
};

// Get all feedback with a specific status
export const getFeedbackByStatus = async (req, res) => {
  const { status } = req.params; // 'approved', 'pending', 'denied'

  if (!['approved', 'pending', 'denied'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status' });
  }

  try {
    const feedback = await Feedback.find({ status })
      .populate('userId', 'name email') // Populating user details
      .populate('hostelId', 'name location') // Populating hostel details
      .populate('roomId', 'roomNumber roomType') // Populating room details
      .exec();

    res.status(200).json(feedback);
  } catch (error) {
    console.error('Error retrieving feedback by status:', error.message);
    res.status(500).json({ error: 'Failed to retrieve feedback by status' });
  }
};
