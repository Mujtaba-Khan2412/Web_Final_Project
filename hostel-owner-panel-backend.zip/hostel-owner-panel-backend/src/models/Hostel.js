import mongoose from 'mongoose';

const HostelSchema = new mongoose.Schema({
  ownerId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  name: { type: String, required: true },
  location: { type: String, required: true },
  description: String,
  categories: [String],
  roomIds: [{ type: mongoose.Schema.Types.ObjectId, ref: "Room" }],
  amenities: [String],
  images: [{ type: String }],
  rating: Number,
  reviews: [{ type: mongoose.Schema.Types.ObjectId, ref: "Review" }],
  isApproved: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

export default mongoose.model("Hostel", HostelSchema);
