// Import Routes
import bookingRoutes from "./routes/bookingRoutes.js";
import customerRoutes from "./routes/customerRoutes.js";
import feedbackRoutes from "./routes/feedbackRoutes.js";
import hostelRoutes from "./routes/hostelRoutes.js";
import complaintRoutes from './routes/complaintRoutes.js';

import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import dotenv from "dotenv";
import cookieParser from "cookie-parser";
import connectDB from "./config/db.js";
import { errorHandler, notFoundHandler } from "./middleware/errorHandler.js";

// Use Routes
app.use("/api/bookings", bookingRoutes);
app.use("/api/customers", customerRoutes);
app.use("/api/feedback", feedbackRoutes);
app.use("/api/hostels", hostelRoutes);
app.use("/api/complaints", complaintRoutes);

// Welcome Route (Base)
app.get("/", (req, res) => {
  res.send("Welcome to the Hostel Management System API!");
});


// Load environment variables
dotenv.config();

const app = express();

// Middleware
app.use(express.json()); // For parsing JSON
app.use(express.urlencoded({ extended: true })); // For parsing URL-encoded data
app.use(cookieParser()); // For handling cookies

// Configure CORS
app.use(cors({
  origin: 'http://localhost:8081', // Replace with your frontend's origin
  methods: ['GET', 'POST', 'PUT', 'DELETE'], // Specify allowed methods
  credentials: true // If you need to send cookies or HTTP authentication
}));

app.use(helmet()); // Security headers
app.use(morgan("dev")); // Logging

// Database Connection
connectDB();

// Static Files (if needed for images/uploads)
app.use("/uploads", express.static("uploads"));

// Mailer (Nodemailer Setup)
import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  service: "gmail", // Example service, use your preferred email service
  auth: {
    user: process.env.EMAIL_USER, // Email address from environment variables
    pass: process.env.EMAIL_PASS, // Email password
  },
});

transporter.verify((error, success) => {
  if (error) {
    console.error("Error verifying mail transporter:", error);
  } else {
    console.log("Mail transporter ready.");
  }
});

// Mail Sending Functionality (Example)
app.post("/send-email", async (req, res) => {
    const { to, subject, text } = req.body;
  
    try {
      await transporter.sendMail({
        from: process.env.EMAIL_USER,
        to,
        subject,
        text,
      });
  
      res.status(200).json({ message: "Email sent successfully!" });
    } catch (error) {
      console.error("Error sending email:", error);
      res.status(500).json({ message: "Failed to send email.", error: error.message });
    }
  });
  
  // Error Handling Middleware
 // app.use(notFoundHandler); // Handle 404 Not Found
  app.use(errorHandler); // General Error Handling

// Server
