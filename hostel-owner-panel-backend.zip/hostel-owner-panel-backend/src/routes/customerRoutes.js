import express from 'express';
import {
  getAllCustomers,
  getCustomerProfile,
  updateCustomerProfile,
  getCustomerBookingHistory,
  submitFeedback,
  fileComplaint,
  getCustomerFeedback,
  createCustomer,
  deleteCustomer,
  getCustomerById,
  getCustomerComplaints,
  updateCustomerStatus
} from '../controllers/customerController.js';

const router = express.Router();

router.put('/:customerId/status', updateCustomerStatus);

// Route to get all customers
router.get('/', getAllCustomers);

// Route to get a specific customer profile
router.get('/:customerId', getCustomerProfile);

// Route to update a customer profile
router.put('/:customerId', updateCustomerProfile);

// Route to get booking history for a customer
router.get('/:customerId/booking-history', getCustomerBookingHistory);

// Route to submit feedback
router.post('/:customerId/feedback', submitFeedback);

// Route to file a complaint
router.post('/:customerId/complaint', fileComplaint);

// Route to get feedback history for a customer
router.get('/:customerId/feedback-history', getCustomerFeedback);

// Route to create a new customer profile
router.post('/', createCustomer);

// Route to delete a customer profile
router.delete('/:customerId', deleteCustomer);

// Route to get a specific customer profile by ID (alternative route)
router.get('/profile/:customerId', getCustomerById);

// Route to get complaints history for a customer
router.get('/:customerId/complaints-history', getCustomerComplaints);

export default router;
