import express from 'express';
import {
  postComplaint,
  deleteComplaint,
  getUserComplaints,
  getAllComplaints,
} from '../controllers/complaintController.js';

const router = express.Router();

// Route to post a new complaint
router.post('/', postComplaint);

// Route to delete a complaint by ID
router.delete('/:complaintId', deleteComplaint);

// Route to get all complaints by a user
router.get('/user', getUserComplaints);

// Route to get all complaints
router.get('/', getAllComplaints);

export default router; 