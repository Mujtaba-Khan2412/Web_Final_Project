import express from 'express';
import {
  getHostelFeedback,
  getRoomFeedback,
  submitFeedback,
  deleteFeedback,
  getFeedbackById,
  getAllFeedback,
  moderateFeedback,
  getFeedbackByStatus
} from '../controllers/feedbackController.js';

const router = express.Router();

// Get all feedback for a specific hostel
router.get('/hostels/:hostelId/feedback', getHostelFeedback);

// Get all feedback for a specific room
router.get('/rooms/:roomId/feedback', getRoomFeedback);

// Submit feedback for a hostel or room
router.post('/customers/:customerId/feedback', submitFeedback);

// Delete feedback by feedbackId
router.delete('/feedback/:feedbackId', deleteFeedback);

// Get feedback by ID
router.get('/feedback/:feedbackId', getFeedbackById);

// Get all feedback
router.get('/feedback', getAllFeedback);

// Approve or deny feedback (admin functionality)
router.put('/feedback/:feedbackId/moderate', moderateFeedback);

// Get all feedback with a specific status (approved, pending, denied)
router.get('/feedback/status/:status', getFeedbackByStatus);

export default router;
