import express from 'express';
import {
  createHostel,
  getAllHostels,
  getHostelById,
  updateHostel,
  deleteHostel,
  moderateHostel,
  getHostelReviews
} from '../controllers/hostelController.js';

const router = express.Router();

// Create a new hostel
router.post('/create', createHostel);

// Get all hostels
router.get('/', getAllHostels);

// Get hostel details by ID
router.get('/hostels/:hostelId', getHostelById);  

// Update hostel details
router.put('/hostels/:hostelId', updateHostel);

// Delete a hostel
router.delete('/hostels/:hostelId', deleteHostel);

// Approve or reject a hostel (admin functionality)
router.put('/hostels/:hostelId/moderate', moderateHostel);

// Get reviews for a specific hostel
router.get('/hostels/:hostelId/reviews', getHostelReviews);

export default router;
