import express from 'express';
import {
  createBooking,
  getAllBookings,
  getBookingsByUser,
  cancelBooking,
  getBookingById,
  updateBooking
} from '../controllers/bookingController.js';

const router = express.Router();

// Route to create a new booking
router.post('/create', createBooking);

// Route to retrieve all bookings
router.get('/', getAllBookings);

// Route to retrieve bookings for a specific user
router.get('/:userId', getBookingsByUser);

// Route to retrieve a booking by ID
router.get('/booking/:bookingId', getBookingById);

// Route to update an existing booking
router.put('/update/:userId/:bookingId', updateBooking);

// Route to cancel a booking
router.delete('/cancel/:userId/:bookingId', cancelBooking);

export default router;
