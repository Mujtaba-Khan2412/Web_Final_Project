import express from "express";
import dotenv from "dotenv";
import mongoose from "mongoose";
import {notFoundHandler,errorHandler} from "./src/middleware/errorHandler.js";
import connectDB from "./src/config/db.js";
import bookingRoutes from "./src/routes/bookingRoutes.js";
import customerRoutes from "./src/routes/customerRoutes.js";
import feedbackRoutes from "./src/routes/feedbackRoutes.js";
import hostelRoutes from "./src/routes/hostelRoutes.js";

// Load environment variables
dotenv.config();

// Initialize Express app
const app = express();

// Middleware for parsing JSON requests
app.use(express.json());

// Database connection
connectDB();

// API routes
app.use("/api/bookings", bookingRoutes);
app.use("/api/customers", customerRoutes);
app.use("/api/feedbacks", feedbackRoutes);
app.use("/api/hostels", hostelRoutes);

// Health check endpoint
app.get("/", (req, res) => {
  res.send("API is running...");
});

// Error handling middlewares
//app.use(notFoundHandler);
app.use(errorHandler);

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

